<?php
require_once __DIR__ . '/vendor/autoload.php'; // include mPDF

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "system_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start HTML content
$html = '
<h1 style="text-align: center; color: blue;">Medical Notes</h1>
<style>
    body { font-family: sans-serif; }
    .note {
        border: 1px solid #ccc;
        border-radius: 10px;
        padding: 15px;
        background-color: #f9f9f9;
        margin-bottom: 20px;
        box-shadow: 0 2px 6px rgba(11, 11, 11, 0.2);
    }
    .note h3 { color: blue; margin: 0 0 10px 0; }
    .note p { margin: 5px 0; }
    .note small { color: #555; }
</style>
';

// Query to fetch all medical notes
$sql = "SELECT * FROM medical_notes ORDER BY id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $html .= '<div class="note">';
        $html .= '<h3>Appointment</h3>';
        $html .= '<p><strong>Diagnosis:</strong><br>' . nl2br(htmlspecialchars($row['diagnosis'])) . '</p>';
        $html .= '<p><strong>Treatment Plan:</strong><br>' . nl2br(htmlspecialchars($row['treatment_plan'])) . '</p>';
        $html .= '<p><strong>Follow-up Instructions:</strong><br>' . nl2br(htmlspecialchars($row['follow_up'])) . '</p>';
        $html .= '<small>Note ID: ' . $row['id'] . '</small>';
        $html .= '</div>';
    }
} else {
    $html .= '<p>No medical notes found.</p>';
}

$conn->close();

// Generate PDF
$mpdf = new \Mpdf\Mpdf();
$mpdf->WriteHTML($html);

// Output the PDF in the browser
$mpdf->Output('Medical_Notes.pdf', 'I'); // I = inline view | D = download | F = file save
?>
