-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2025 at 02:10 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `system_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `email`, `password`) VALUES
(1, 'admin123@gmail.com', '$2y$10$olTbH4OuiBYVWgqKhL4H9exhQ60MwHcxdCJne8Z0Ibfb46dENoJLm');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `reason` text DEFAULT NULL,
  `preferred_date` date NOT NULL,
  `preferred_time` time NOT NULL,
  `preferred_doctor` varchar(100) DEFAULT NULL,
  `conditions` text DEFAULT NULL,
  `medications` text DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `consent` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'pending',
  `confirmed_at` datetime DEFAULT NULL,
  `doctor_notes` text DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `first_name`, `last_name`, `email`, `phone`, `dob`, `gender`, `reason`, `preferred_date`, `preferred_time`, `preferred_doctor`, `conditions`, `medications`, `allergies`, `consent`, `created_at`, `status`, `confirmed_at`, `doctor_notes`, `user_id`) VALUES
(12, 'Anna', 'Yanami', 'anna@gmail.com', '09275015924', '2002-01-28', 'female', 'symptoms*', '2025-08-28', '23:11:00', 'Doc. Nuku', 'conditions*', 'medications*', 'none', 1, '2025-05-16 02:02:22', 'pending', NULL, NULL, 0),
(13, 'Kujo ', 'Ang', 'kujo@gmail.com', '09275015925', '2001-11-11', 'female', 'reason*', '2025-02-13', '15:46:00', 'Doc. Saya', 'conditions*', 'none', 'none', 1, '2025-05-16 02:04:03', 'pending', NULL, NULL, 0),
(14, 'Nene', 'Aya', 'ayachi@gmail.com', '09275015923', '1999-12-23', 'female', 'reasons*', '2025-10-05', '14:14:00', 'Doc. Shuji', 'conditions*', 'medications*', 'allergies*', 1, '2025-05-16 02:06:10', 'pending', NULL, NULL, 0),
(26, 'Jaykerd', 'Sario', 'jaykerd123@gmail.com', '09275015924', '2003-01-28', 'male', 'symptoms', '2025-05-28', '11:30:00', 'Dr. Nicanor S. Rojas', 'conditions*', 'medications*', 'allergies*', 1, '2025-05-20 04:02:27', 'pending', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `specialization` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `email`, `password`, `name`, `specialization`) VALUES
(11, 'ray@gmail.com', '$2y$10$LPnIkeJ36WwNQSZGQxBnMugJU6ZtfE8TSJkpV13R2wbGZpOxRnAuS', 'Raymond Nocum', 'Pediatrician'),
(12, 'christ@gmail.com', '$2y$10$C4HU7oVcvpY/9/2V33nkEeLLPTu7auPKpxnAGufoSFzX5SBJXeJTK', 'Christ Tangian', 'Cardiologist'),
(13, 'steph@gmail.com', '$2y$10$mzICdXvT7dPSfLEBo./EFOeWJbYBFrmPfVsQ4YIHnXybh1ZPY3bMq', 'Stephen Caban', 'Dermatologist'),
(14, 'kyle@gmail.com', '$2y$10$Uw45xFuYVTVPIsc6Y1MGyOCMSTn0Ng/1f2NoTIJG3E2gYBO7lL1Ii', 'Kyle Santos', 'Orthopedic Surgeon'),
(16, 'doctor@gmail.com', '$2y$10$H1WKEOnb5arBwjx2uR22beKYoGV6SdNNJ9y/QUxyZYqvxndadcgIC', 'Doctor', 'Neuro'),
(17, 'jaykerd123@gmail.com', '$2y$10$8zWHa075oMup71OHmDQjMedmcCxCMuApyi7hDRr6wzBaijlaAbo.O', 'Jaykerd Sario', 'specialization');

-- --------------------------------------------------------

--
-- Table structure for table `medical_notes`
--

CREATE TABLE `medical_notes` (
  `id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `diagnosis` text NOT NULL,
  `treatment_plan` text NOT NULL,
  `follow_up` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medical_notes`
--

INSERT INTO `medical_notes` (`id`, `appointment_id`, `diagnosis`, `treatment_plan`, `follow_up`, `created_at`) VALUES
(9, 12345, 'Upper Respiratory Tract Infection', 'Prescribed antibiotics and rest', 'Return if fever persists beyond 3 days', '2025-05-16 02:15:37'),
(10, 12345, 'Mild Dehydration', 'Oral rehydration and increased fluid intake', 'Monitor urine output; follow-up in 2 days', '2025-05-16 02:16:03'),
(11, 12345, 'Sprained Ankle', 'R.I.C.E. therapy and pain relievers', 'Avoid strenuous activity; reassess in 1 week', '2025-05-16 02:16:24'),
(12, 12345, 'Hypertension', 'Start antihypertensive meds, lifestyle changes', 'BP check in 1 week, labs in 2 weeks', '2025-05-16 02:16:46'),
(13, 12345, 'Mild Acne', 'Topical benzoyl peroxide', 'Apply daily; return in 4 weeks for review', '2025-05-16 02:17:06'),
(14, 12345, 'diagnosis', 'plan', 'intrsu', '2025-05-19 23:44:49'),
(15, 12345, 'diagnosis', 'plan', 'follow-up', '2025-05-20 03:49:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `reset_code` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `reset_code`) VALUES
(18, 'User123', 'user@gmail.com', '$2y$10$CpOGuUih5FxmABUD1ikQfeszx2tUs8ysTjRaO5UTvMCRiMOiJVFym', NULL),
(19, 'Jake', 'jaykerd123@gmail.com', '$2y$10$UvDBK9VRWxsDCeor4X6ipu5/Suc4SjfM/h0p.FNw/khxGUrHeZPPK', '729840'),
(22, 'Jaykerd Sario', '2301107547@student.buksu.edu.ph', '$2y$10$y4dEHAZ/KE7pFwCz/zrZROTpqT0j0L3HK5OziFqfeVpMt.AiDjNfi', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `medical_notes`
--
ALTER TABLE `medical_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `medical_notes`
--
ALTER TABLE `medical_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
