<?php
session_start(); // Start the session

// reCAPTCHA secret key
$recaptchaSecret = "6Lfmtz0rAAAAAOODxijv0U2iObanr-V7JA2Hu78t";
$recaptchaResponse = $_POST['g-recaptcha-response'] ?? '';

// Check if reCAPTCHA is completed
if (empty($recaptchaResponse)) {
    echo "<script>alert('Please complete the reCAPTCHA.'); window.history.back();</script>";
    exit();
}

// Verify reCAPTCHA
$verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$recaptchaSecret&response=$recaptchaResponse");
$responseKeys = json_decode($verify, true);

if (!$responseKeys["success"]) {
    echo "<script>alert('reCAPTCHA verification failed. Are you a robot?'); window.history.back();</script>";
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "system_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data
$email = $_POST['email'] ?? '';
$password_input = $_POST['password'] ?? '';

if (empty($email) || empty($password_input)) {
    echo "<script>alert('Please enter both email and password.'); window.history.back();</script>";
    exit();
}

// Check if user exists
$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    if (password_verify($password_input, $user['password'])) {
        // Set session variables upon successful login
        $_SESSION['id'] = $user['id'];      // <-- use 'id' here
        $_SESSION['email'] = $user['email'];
        $_SESSION['name'] = $user['name'];

        // Standard login check
        $_SESSION['logged_in'] = true;

        // Redirect to the index page after successful login
        header("Location: index.php");
        exit();
    } else {
        echo "<script>
            alert('Incorrect password. Please try again.');
            window.history.back();
          </script>";
    }
} else {
    echo "<script>
        alert('User not found. Please register.');
        window.history.back();
      </script>";
}

$stmt->close();
$conn->close();
?>
