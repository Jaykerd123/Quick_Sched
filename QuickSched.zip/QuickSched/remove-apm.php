<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "system_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["appointment_id"])) {
    $id = intval($_POST["appointment_id"]);
    $sql = "DELETE FROM appointments WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header("Location: user-list.php"); // change this to your main view file name if different
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

$conn->close();
?>
