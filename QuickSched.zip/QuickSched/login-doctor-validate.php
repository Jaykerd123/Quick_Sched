<?php
session_start(); // Start session

// reCAPTCHA Secret Key
$recaptchaSecret = "6Lfmtz0rAAAAAOODxijv0U2iObanr-V7JA2Hu78t";
$recaptchaResponse = $_POST['g-recaptcha-response'] ?? '';

// Check if reCAPTCHA was completed
if (empty($recaptchaResponse)) {
    echo "<script>alert('Please complete the reCAPTCHA.'); window.history.back();</script>";
    exit();
}

// Verify reCAPTCHA response with Google
$verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$recaptchaSecret&response=$recaptchaResponse");
$responseKeys = json_decode($verify, true);

if (!$responseKeys["success"]) {
    echo "<script>alert('reCAPTCHA verification failed.'); window.history.back();</script>";
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'system_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    echo "<script>alert('Please enter both email and password.'); window.history.back();</script>";
    exit();
}

// Check if the doctor exists
$sql = "SELECT * FROM doctors WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// If doctor found
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        // Login success
        $_SESSION['doctor_id'] = $user['id'];
        $_SESSION['doctor_email'] = $user['email'];

        header("Location: index-doctor.php");
        exit();
    } else {
        echo "<script>alert('Incorrect password!'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Doctor not found!'); window.history.back();</script>";
}

$stmt->close();
$conn->close();
?>
