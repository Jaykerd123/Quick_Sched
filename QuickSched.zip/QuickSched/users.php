<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login-admin.php"); // Redirect to login if not logged in
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'system_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle deletion if triggered
if (isset($_GET['delete_id'])) {
    $deleteId = intval($_GET['delete_id']);
    $conn->query("DELETE FROM doctors WHERE id = $deleteId");
    // Optional: redirect to avoid resubmission
    header("Location: users.php");
    exit();
}

// Fetch all doctors
$sql = "SELECT * FROM doctors";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctors</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            margin-top: 120px;
            height: 80vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #header-navigation {
            display: flex;
            justify-content: right;
        }

        .header-option {
            border: 1px solid blue;
            width: 20%;
            border-radius: 10px;
            color: white;
        }
        
        table {
            width: 95%;
            margin: 20px auto;
        }

        th, td {
            padding: 10px;
            border: 1px solid #999;
            text-align: left;
        }

        th {
            background-color: #eee;
        }

        .btn-delete {
            background-color: #e74c3c;
            color: white;
            padding: 6px 12px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        .btn-delete:hover {
            background-color: #c0392b;
        }

        /* DOCTOR TABLE */

        #doctor-cont {
            width: 80%;
            background-color: rgba(252, 252, 252, 0.52);
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(11, 11, 11, 0.5);
        }
        
    </style>
</head>
<body>
    <!-- HEADER -->
    <nav>
        <div id="head-container">
            <div><img id="logo" src="images/quicksched_logo.png" alt="quicksched_logo"></div>
            <!-- OPTIONS -->
            <div id="header-navigation">
                <div class="header-option"><a href="index-admin.php" class="hover-grow" style="color: blue;">HOME</a></div>
            </div>
        </div>
    </nav>

    <div id="doctor-cont">
    <h2 style="text-align:center;">List of Doctors</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Specialization</th>
            <th>Action</th>
        </tr>

        <?php if ($result->num_rows > 0): ?>
            <?php while($doctor = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $doctor['id']; ?></td>
                    <td><?= $doctor['name']; ?></td>
                    <td><?= $doctor['email']; ?></td>
                    <td><?= $doctor['specialization']; ?></td>
                    <td>
                        <a href="users.php?delete_id=<?= $doctor['id']; ?>" 
                           onclick="return confirm('Are you sure you want to delete this doctor?');">
                           <button class="btn-delete">Remove</button>
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">No doctors found.</td>
            </tr>
        <?php endif; ?>
    </table>
    </div>

    
</body>
</html>

<?php
$conn->close();
?>
