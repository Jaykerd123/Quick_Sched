<?php

session_start();

if (!isset($_SESSION['doctor_id'])) {
    header("Location: login-doctor.php"); // Redirect if not logged in
    exit();
}
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "system_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query all appointments
$sql = "SELECT * FROM appointments";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Medical Notes</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            margin-top: 120px;
            height: 80vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        h1 {
            font-family: sans-serif;
        }

        #header-navigation {
            display: flex;
            justify-content: right;
        }

        .header-option {
            border: 1px solid blue;
            width: 20%;
            border-radius: 10px;
            color: white;
        }

        #medical-notes {
            width: 80%;
            height: 500px;
            display: flex;
            justify-content: center;
            flex-direction: column;
            gap: 20px;
            padding: 40px;
            box-shadow: 0 2px 6px rgba(11, 11, 11, 0.5);
            border-radius: 10px;
            background-color: rgba(246, 244, 244, 0.73);
        }
        textarea {
            width: 100%;
        }
        label {
            font-weight: bold;
        }
        
        button {
            height: 18%;
            width: 15%;
            border-radius: 5px;
            border: none;
            background-color: blue;
            color: white;
            font-size: 20px;
        }

        button:hover {
            transform: scale(1.03);
            background-color: rgb(117, 128, 245);
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <nav>
        <div id="head-container">
            <div><img id="logo" src="images/quicksched_logo.png" alt="quicksched_logo"></div>
            <!-- OPTIONS -->
            <div id="header-navigation">
                <div class="header-option"><a href="index-doctor.php" class="hover-grow" style="color: blue;">HOME</a></div>
            </div>
        </div>
    </nav>

    <div id="medical-notes">
    <h2>Add Medical Notes</h2>

    <form action="save_notes.php" method="POST">
    <!-- Simulate appointment ID or patient ID -->
    <input type="hidden" name="appointment_id" value="12345">

    <label>Diagnosis:</label>
    <textarea name="diagnosis" required></textarea>
    <br>
    <br>
    <label>Treatment Plan:</label>
    <textarea name="treatment" required></textarea>
    <br>
    <br>
    <label>Follow-up Instructions:</label>
    <textarea name="follow_up" required></textarea>
    <br>
    <br>
    <button type="submit">Save Notes</button>
</form>
    </div>

    <script src="index.js"></script>
    
    <script>
             const hamburger = document.getElementById("hamburger-menu");
            const dropdown = document.getElementById("hamburger-dropdown");

            hamburger.addEventListener("click", () => {
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
            });

            window.addEventListener("click", (event) => {
            if (!hamburger.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = "none";
            }
            });
    </script>

</body>
</html>

<?php
$conn->close();
?>
