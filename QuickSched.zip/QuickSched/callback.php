<?php
require_once 'vendor/autoload.php';

session_start();

$client = new Google_Client();
$client->setClientId('289589988881-lf3111t8vjppo4veo2rbk1m6jn95vi3g.apps.googleusercontent.com');
$client->setClientSecret('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');
$client->setRedirectUri('http://localhost/System/callback.php');

$client->setHttpClient(new \GuzzleHttp\Client(['debug' => true]));

if (isset($_GET['code'])) {
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    
    if (!isset($token["error"])) {
        $client->setAccessToken($token['access_token']);
        
        // Get user profile
        $oauth = new Google_Service_Oauth2($client);
        $userData = $oauth->userinfo->get();

        // Save user info to session
        $_SESSION['user_name'] = $userData->name;
        $_SESSION['user_email'] = $userData->email;
        $_SESSION['user_picture'] = $userData->picture;

        // Redirect to index.php
        header('Location: index.php');
        exit();

    } else {
        echo "Error fetching token.";
    }
} else {
    echo "No code returned from Google.";
}
