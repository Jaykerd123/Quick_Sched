<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <link rel="stylesheet" href="style.css">

    <style> 
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh;
        }

        #back-button {
            height: 25px;
            width: 25px;
            margin-left: 95%;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        #back-button:hover {
            transform: scale(1.2); /* scales 20% bigger on hover */
        }

        #p-id {
            margin-top: 150px;
            size: 40px;
            font-weight: 500;
            color: rgba(6, 6, 6, 0.64);
        }
        
        input {
            border-radius: 5px;
            height: 40px;
            padding: 5px;
            margin: 5px;
        }

        button {
            border: none;
            border-radius: 10px;
            background-color: blue;
            color: white;
            height: 50px;
            margin: 5px;
            font-weight: bold;
        }

        button:hover {
            transform: scale(1.01);
            background-color: rgba(46, 76, 249, 0.64);
        }

        .child-login-container-right {
            flex-direction: column;
        }

        form {
            display: flex;
            flex-direction: column;
        }
    </style>
</head>
<body>
    <div id="login-container">
        <div class="child-login-container-left">
            <img id="quicksched_logo" src="images/quicksched_logo.png" alt="logo">
            <p id="welcome-greeting">Hello, 
            <br><span style="font-size: 40px;">Welcome</span>
            </p>
            <p style="color: rgba(43, 42, 42, 0.642);
                      margin-left: 25px;">Quick Scheduling right at your fingertips</p>
        </div>

        

        <div class="child-login-container-right">
            <!-- X button -->
            <a href="login.php">
                <img id="back-button" src="images/arrow.png" alt="arrow" style="height: 25px; 
                                                           width: 25px;
                                                           margin-left: 95%;">
            </a>

            <form method="post" action="resetting.php">
                <p id="p-id">Input new password</p>
                <input type="password" name="password" placeholder="password" required>
                <button type="submit">Update</button>
            </form>
            </div>
    </div>
</body>
</html>