<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "system_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the appointment ID from the POST data
    $appointment_id = $_POST['appointment_id'];

    // SQL query to delete the appointment
    $sql = "DELETE FROM appointments WHERE id = ?";

    // Prepare and bind
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $appointment_id);

    // Execute the query
    if ($stmt->execute()) {
        echo "<script>alert('Appointment deleted successfully!'); window.location.href='index-doctor.php';</script>";
    } else {
        echo "<script>alert('Error: Could not delete appointment.'); window.history.back();</script>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
