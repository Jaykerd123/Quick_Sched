<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// Database credentials
$host = "localhost";
$username = "root";
$password = "";
$database = "system_db";

// Check POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit;
    }

    // Connect to database
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Check if email exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            echo "Email not found in our records.";
            exit;
        }

        // Generate a 6-digit code
        $verification_code = rand(100000, 999999);

        // Store in session for later verification
        $_SESSION['reset_code'] = (string)$verification_code;
        $_SESSION['email'] = $email;


        // Send email using PHPMailer
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'jaykerd123@gmail.com';
            $mail->Password   = 'xavx uion mxzl askk'; // Your Gmail App Password (16 characters, no spaces in actual)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;


            //Recipients
            $mail->setFrom('jaykerd123@gmail.com', 'QuickSched');
            $mail->addAddress($email);

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your Verification Code';
            $mail->Body    = "Your verification code is: <b>$verification_code</b>";

            $mail->send();

            echo "Verification code sent to your email.";

            // Redirect to code verification page if you want
            header('Location: verify-code.php');
            exit;

        } catch (Exception $e) {
            echo "Mailer Error: {$mail->ErrorInfo}";
        }

    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo "Please submit your email.";
}
