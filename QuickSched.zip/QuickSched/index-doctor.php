<?php
session_start();

if (!isset($_SESSION['doctor_id'])) {
    header("Location: login-doctor.php"); // Redirect if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
    <style>

        body {
            height: 50vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 230px;
        }

        #head-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 99%;
        }

        a {
            font-size: 20px;
            color: blue;
        }

        #doctor-front {
            width: 98%;
            height: 500px;
            display: flex;
            padding-left: 60px;
        }

        #doctor-front-left {
            width: 60%;
            height: 100%;
            display: flex;
            border-radius: 5px;
            box-shadow: 0 2px 6px rgba(11, 11, 11, 0.2);
            background-color: rgba(246, 244, 244, 0.73);
            padding-right: 20px;
        }

        #doctor-front-right {
            width: 40%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 20px;
        }

        #doctor-front-right button {
            height: 18%;
            width: 60%;
            border-radius: 20px;
            border: none;
            background: linear-gradient(to right, rgb(2, 69, 224), rgb(7, 168, 249));
            color: white;
            font-size: 20px;
        }

        #btn-1:hover {
            background: linear-gradient(to right, rgb(99, 146, 255), rgb(99, 146, 255));
            transform: scale(1.02);
        }

        #btn-2:hover {
            background: linear-gradient(to right, rgb(99, 146, 255), rgb(99, 146, 255));
            transform: scale(1.02);
        }

        #btn-3:hover {
            background: linear-gradient(to right, rgb(99, 146, 255), rgb(99, 146, 255));
            transform: scale(1.02);
        }

        #btn-4:hover {
            background: linear-gradient(to right, rgb(99, 146, 255), rgb(99, 146, 255));
            transform: scale(1.02);
        }

        #dcfl {
            width: 40%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #dcfl img {
            width: 80%;
            height: 70%;
        }

        #dcfr {
            width: 60%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        #dcfr p{
            font-size: 20px;
            color: rgba(11, 11, 11, 0.65);
        }

        #prof:hover {
            transform: scale(1.03);
            cursor: pointer;
        }
    </style>
</head>
<body>

    <!-- HEADER -->
    <nav>
        <div id="head-container">
            <div><img id="logo" src="images/quicksched_logo.png" alt="quicksched_logo"></div>
            <div>
                <img id="prof" onclick="location.href='profile-doctor.php'" src="images/account.png" alt="">
            </div>
        </div>
    </nav>

    <!-- DOCTOR FRONT -->
    <div id="doctor-front">
        <div id="doctor-front-left">
            <div id="dcfl">
                <img src="images/doctor-front.png" alt="">
            </div>
            <div id="dcfr">
                <h1>Welcome back, Doc!</h1>
                <p>Your patients are counting on you. Let’s take a look.</p>
            </div>
        </div>
        <div id="doctor-front-right">
            <button id="btn-1" onclick="location.href='appointment-list.php'">View Appointments</button>
            <button id="btn-2" onclick="location.href='medical-notes.php'">Add Medical Notes</button>
            <button id="btn-3" onclick="window.open('view_notes.php', '_blank')">Display Notes</button>
            <button id="btn-4" onclick="location.href='delete_appointment.php'">Remove Patients</button>
        </div>
    </div>

    <script src="index.js"></script>
    <script>
             const hamburger = document.getElementById("hamburger-menu");
            const dropdown = document.getElementById("hamburger-dropdown");

            hamburger.addEventListener("click", () => {
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
            });

            window.addEventListener("click", (event) => {
            if (!hamburger.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = "none";
            }
            });
    </script>
</body>
</html>