<?php
session_start();

if (!isset($_SESSION['user_name']) && !isset($_SESSION['name'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Details</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            margin-top: 140px;
            height: 50vh;
        }

        #header-navigation {
            display: flex;
            justify-content: right;
        }

        .doc-inf {
            width: 85%;
            height: 580px;
            margin-left: 100px;
            background-color: rgba(254, 252, 252, 0.34);
        }

        .doc-det {
            width: 100%;
            background-color: rgba(254, 252, 252, 0.34);
            padding: 10px;
        }

        .doc-prof {
            width: 98%;
            background: linear-gradient(to bottom, rgb(2, 102, 224), rgb(0, 20, 119));
            border: 9px double white;
            display: flex;
            padding: 10px;
            color: white;
        }

        .doc-pic {
            width: 90%;
        }

        .doc-left {
            width: 20%;
        }

        .doc-right {
            width: 80%;
            font-size: 20px;
        }

        h3 {
            color: blue;
            margin-left: 10px;
        }

        #appointment-button {
            margin-top: 10px;
            height: 50px;
            font-size: 20px;
            width: 90%;
            border: 2px double white;
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <nav>
        <div id="head-container">
            <div><img id="logo" src="images/quicksched_logo.png" alt="quicksched_logo"></div>
            <div id="header-navigation" style="margin-left: 300px;">
                <div class="header-option"><a href="index.php" class="hover-grow">HOME</a></div>
                <div class="header-option"><a href="profile.php" class="hover-grow">PROFILE</a></div>
            </div>
        </div>
    </nav>

    <!-- DOCTOR INFO -->

    <div class="doc-inf">
        <div class="doc-det">
            <h2>Doc Nicanor</h2>
            <p><u><i>Pediatric Cardiologist</i></u></p>
        </div>
        <div class="doc-prof">
            <div class="doc-left">
                <img class="doc-pic" src="images/rojas.jpeg" alt="">
                <button id="appointment-button" onclick="window.location.href='appointment-form.php'">GET APPOINTED</button>
            </div>
            <div class="doc-right">
                <p><b>Full name:</b> Nicanor S. Rojas</p>
                <p><b>Years of Experience: </b> 8 years</p>
                <p><b>Hospital/Clinic Affiliation: </b> Bukidnon Provincial Hospital</p>
                <p><b>Clinic Schedule: </b>Mon–Fri, 9:00 AM–3:00 PM</p>
                <p><b>Availability: </b> ✅ Available</p>
            </div>
        </div>
        <h3>Quick bio</h3>
        <p style="margin-left: 10px;">
            <i>
                Dr. Nicanor S. Rojas is a dedicated Internal Medicine specialist renowned for her compassionate approach and meticulous attention to detail. With over 12 years of clinical experience, she excels in diagnosing and managing complex adult medical conditions, including hypertension, diabetes, and cardiovascular diseases.
            </i>
        </p>
    </div>

</body>
</html>