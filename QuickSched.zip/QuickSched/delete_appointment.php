<?php
session_start();

if (!isset($_SESSION['doctor_id'])) {
    header("Location: login-doctor.php"); // Redirect if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Appointment List</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            margin-top: 120px;
            height: 80vh;
        }

        h1 {
            font-family: sans-serif;
        }

        #header-navigation {
            display: flex;
            justify-content: right;
        }

        .header-option {
            border: 1px solid blue;
            width: 20%;
            border-radius: 10px;
            color: white;
        }

        #del-table {
            background-color: white;
            width: 60%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            border-radius: 10px;
            margin-left: 300px;
            flex-direction: column;
            box-shadow: 0 2px 6px rgba(11, 11, 11, 0.2);
        }

        button {
            margin-left: 150px;
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <nav>
        <div id="head-container">
            <div><img id="logo" src="images/quicksched_logo.png" alt="quicksched_logo"></div>
            <!-- OPTIONS -->
            <div id="header-navigation">
                <div class="header-option"><a href="index-doctor.php" class="hover-grow" style="color: blue;">HOME</a></div>
            </div>
        </div>
    </nav>

    <div id="del-table">
        <h1>Appointing Patients List</h1>
        <table border="1" cellpadding="10" width="95%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Patient Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Assuming you have a connection to your database already.
                $conn = new mysqli('localhost', 'root', '', 'system_db'); // Update credentials as necessary
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $result = $conn->query("SELECT * FROM appointments"); // Adjust your table name as needed

                while ($row = $result->fetch_assoc()):
                ?>
                    <tr>
                        <td><?= $row["id"] ?></td>
                        <td><?= $row["first_name"] . " " . $row["last_name"] ?></td>
                        <td><?= $row["email"] ?></td>
                        <td>
                            <form method="POST" action="delete_appointment_process.php" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this appointment?');">
                                <input type="hidden" name="appointment_id" value="<?= $row['id'] ?>">
                                <button type="submit" style="background-color:red;color:white;border:none;padding:5px 10px;border-radius:5px;">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

    </div>


    <script src="index.js"></script>
    
    <script>
             const hamburger = document.getElementById("hamburger-menu");
            const dropdown = document.getElementById("hamburger-dropdown");

            hamburger.addEventListener("click", () => {
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
            });

            window.addEventListener("click", (event) => {
            if (!hamburger.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = "none";
            }
            });
    </script>

</body>
</html>