<?php
// Include the Composer autoloader
require_once __DIR__ . '/vendor/autoload.php';

// Create an instance of mPDF
$mpdf = new \Mpdf\Mpdf();

// Define your HTML content
$html = '
<h1 style="color: #007bff;">Hello from mPDF!</h1>
<p>This PDF was generated using <strong>mPDF</strong>.</p>
';

// Write HTML to PDF
$mpdf->WriteHTML($html);

// Output the PDF inline in the browser
$mpdf->Output('example.pdf', 'I'); // 'I' for inline preview
?>
