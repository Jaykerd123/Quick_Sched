<?php
session_start();

// Make sure user is logged in
if (!isset($_SESSION['id'])) {
    echo "Access denied. Please log in.";
    exit();
}

// Check if appointment ID is provided
if (!isset($_POST['id'])) {
    echo "Invalid request.";
    exit();
}

$appointment_id = intval($_POST['id']);
$user_id = $_SESSION['id'];

// DB connection
$conn = new mysqli("localhost", "root", "", "system_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Verify that the appointment belongs to this user before deleting
$sql = "SELECT * FROM appointments WHERE id = ? AND id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $appointment_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Appointment not found or access denied.";
    exit();
}
$stmt->close();

// Delete the appointment
$sql_delete = "DELETE FROM appointments WHERE id = ? AND id = ?";
$stmt_delete = $conn->prepare($sql_delete);
$stmt_delete->bind_param("ii", $appointment_id, $user_id);
if ($stmt_delete->execute()) {
    echo "<script>alert('Appointment cancelled successfully.'); window.location.href='user-data.php';</script>";
} else {
    echo "<script>alert('Failed to cancel appointment.'); window.history.back();</script>";
}

$stmt_delete->close();
$conn->close();
?>
