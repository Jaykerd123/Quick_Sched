<?php
session_start();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    $new_password = $_POST['password'];
    $email = $_SESSION['email'] ?? null;

    if (!$email) {
        echo "<script>alert('Session expired. Please start the reset process again.'); window.location.href = 'fp-code.php';</script>";
        exit;
    }

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "system_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Update password in the database
    $sql = "UPDATE users SET password = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $hashed_password, $email);

    if ($stmt->execute()) {
        // Clear session
        unset($_SESSION['email']);
        echo "<script>alert('Password updated successfully!'); window.location.href = 'login.php';</script>";
    } else {
        echo "<script>alert('Failed to update password. Please try again.'); window.location.href = 'resetting-form.php';</script>";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Invalid access.'); window.location.href = 'fp-code.php';</script>";
}
?>
