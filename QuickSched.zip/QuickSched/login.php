<?php
require_once 'vendor/autoload.php';

session_start();

// Init Google Client
$client = new Google_Client();
$client->setClientId('289589988881-lf3111t8vjppo4veo2rbk1m6jn95vi3g.apps.googleusercontent.com');
$client->setClientSecret('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');
$client->setRedirectUri('http://localhost/System/callback.php');
$client->addScope("email");
$client->addScope("profile");

// Generate Auth URL
$authUrl = $client->createAuthUrl();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">

    <!-- CSS -->
    <style> 
        body {
            background: url('images/bg-web.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh;
        }

        #back-button {
            height: 25px;
            width: 25px;
            margin-left: 95%;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        #back-button:hover {
            transform: scale(1.2); /* scales 20% bigger on hover */
        }
    </style>
</head>
<body>
    <!-- LOGIN CONTAINER -->
    <div id="login-container">
        <!-- LEFT CONTAINER -->
        <div class="child-login-container-left">
            <img id="quicksched_logo" src="images/quicksched_logo.png" alt="logo">
            <p id="welcome-greeting">Hello, 
            <br><span style="font-size: 40px;">Welcome</span>
            </p>
            <p style="color: rgba(43, 42, 42, 0.642);
                      margin-left: 25px;">Quick Scheduling right at your fingertips</p>
        </div>
        <!-- RIGHT CONTAINER -->
        <div class="child-login-container-right">

            <a href="website.php">
                <img id="back-button" src="images/arrow.png" alt="arrow" style="height: 25px; 
                                                           width: 25px;
                                                           margin-left: 95%;">
            </a>
            <!-- LOGIN FORM -->
            <form method="post" action="login.validate.php">
                <p style="font-size: 30px; margin: 0;">Let's get started!</p>
                <p style="color: rgb(104, 103, 103);">Login to schedule appointments.</p>
                <input type="email" name="email" class="input-box" placeholder="Email" required><br>
                <input type="password" name="password" class="input-box" placeholder="Password" required
                    pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                    title="Must contain at least 8 characters, including UPPER/lowercase and a number"><br>
                <br>
                <div class="g-recaptcha" data-sitekey="6Lfmtz0rAAAAALoDuG50rik2MlAR0T2Jf8-_NP1m"></div>
                <script src="https://www.google.com/recaptcha/api.js" async defer></script>
                <button type="submit" id="login-btn">LOGIN</button>
                <br>
                <br>
                <a href="forgot-password.php" style="font-size: 12px; color: blue; margin-left: 5px;">Forgot password?</a>
            </form>
            <p style="margin-top: 20px;
                      color: gray;
                      font-size: 12px">Google login? <span style="font-weight: bold;">Click</span><span><a href="<?php echo $authUrl; ?>" style="margin-left: 3px; margin-bottom: 4px;"><u>here</u></a>
</span></p>
        </div>
    </div>
</body>
</html>