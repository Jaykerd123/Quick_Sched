<?php
require_once 'vendor/autoload.php';

$client = new Google_Client();
$client->setClientId('289589988881-lf3111t8vjppo4veo2rbk1m6jn95vi3g.apps.googleusercontent.com');
$client->setClientSecret('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');
$client->setRedirectUri('http://localhost/System/callback.php');

// Simulate a test token request manually
// NOTE: Replace this with an actual valid code from your Google OAuth callback URL to test properly
$testCode = '4%2F0AUJR-x6NVrH3rPp-jeeCwVOSDGgj1Jh9sVqku8M8LffqlajCDiVqqIzVmEXpOK5L8ZvARQ&scope=email+profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+openid&authuser=0&prompt=consent'; 

if (!$testCode) {
    die('Please edit this file and paste your actual OAuth code into $testCode to test.');
}

try {
    $token = $client->fetchAccessTokenWithAuthCode($testCode);
    echo '<h3>Token response:</h3><pre>';
    print_r($token);
    echo '</pre>';
} catch (Exception $e) {
    echo 'Caught exception: ', $e->getMessage();
}
