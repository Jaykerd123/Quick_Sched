<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login-admin.php"); // Redirect to login if not logged in
    exit();
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Add Doctor</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            margin-top: 120px;
            height: 80vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #header-navigation {
            display: flex;
            justify-content: right;
        }

        .header-option {
            border: 1px solid blue;
            width: 20%;
            border-radius: 10px;
            color: white;
        }
        
        form {
            width: 85%;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
        }

        input[type="text"], input[type="email"], input[type="password"] {
            width: 95%;
            padding: 10px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #aaa;
            border-radius: 5px;
        }

        input[type="submit"] {
            background-color: #27ae60;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #219150;
        }

        #add-doc-ctn {
            width: 40%;
            background-color:rgba(255, 255, 255, 0.35);
            box-shadow: 0 2px 6px rgba(11, 11, 11, 0.5);
            border-radius: 10px;
        }
        
    </style>
</head>
<body>
    <!-- HEADER -->
    <nav>
        <div id="head-container">
            <div><img id="logo" src="images/quicksched_logo.png" alt="quicksched_logo"></div>
            <!-- OPTIONS -->
            <div id="header-navigation">
                <div class="header-option"><a href="index-admin.php" class="hover-grow" style="color: blue;">HOME</a></div>
            </div>
        </div>
    </nav>

    <div id="add-doc-ctn">
        <form action="process-add-doctor.php" method="POST">
            <h2>Add Doctor</h2>
            <label>Name:</label>
            <input type="text" name="name" required>

            <label>Specialization:</label>
            <input type="text" name="specialization" required>

            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Password:</label>
            <input type="password" name="password" required>

            <input type="submit" value="Add Doctor">
        </form>
    </div>

    
</body>
</html>
