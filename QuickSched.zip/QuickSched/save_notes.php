<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "system_db"; // keep your DB name consistent

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get data from form
    $appointment_id = $_POST['appointment_id'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    $follow_up = $_POST['follow_up'];

    // SQL query to insert medical notes
    $sql = "INSERT INTO medical_notes (appointment_id, diagnosis, treatment_plan, follow_up)
            VALUES (?, ?, ?, ?)";

    // Prepare statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $appointment_id, $diagnosis, $treatment, $follow_up);

    // Execute the query
    if ($stmt->execute()) {
        echo "<script>alert('Medical notes saved successfully!'); window.location.href='index-doctor.php';</script>";
    } else {
        echo "<script>alert('Error: Could not save notes.'); window.history.back();</script>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
