<?php
session_start();

// reCAPTCHA Secret Key
$recaptchaSecret = "6Lfmtz0rAAAAAOODxijv0U2iObanr-V7JA2Hu78t";
$recaptchaResponse = $_POST['g-recaptcha-response'] ?? '';

// Check if reCAPTCHA is filled
if (empty($recaptchaResponse)) {
    echo "<script>alert('Please complete the reCAPTCHA.'); window.history.back();</script>";
    exit();
}

// Verify reCAPTCHA with Google
$verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$recaptchaSecret&response=$recaptchaResponse");
$responseKeys = json_decode($verify, true);

if (!$responseKeys["success"]) {
    echo "<script>alert('reCAPTCHA verification failed. Are you a robot?'); window.history.back();</script>";
    exit();
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'system_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get submitted form data
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    echo "<script>alert('Please enter both email and password.'); window.history.back();</script>";
    exit();
}

// Query the admin with the provided email
$sql = "SELECT * FROM admins WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Check if admin exists
if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();

    // Verify the password
    if (password_verify($password, $admin['password'])) {
        // Login success, store session
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_email'] = $admin['email'];

        // Redirect to admin dashboard
        header("Location: index-admin.php");
        exit();
    } else {
        echo "<script>alert('Incorrect password!'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Admin not found!'); window.history.back();</script>";
}

$conn->close();
?>
