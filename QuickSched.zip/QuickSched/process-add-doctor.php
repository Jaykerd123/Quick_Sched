<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'system_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form values
$name = $_POST['name'];
$specialization = $_POST['specialization'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password

// Insert into the database
$sql = "INSERT INTO doctors (name, specialization, email, password) 
        VALUES ('$name', '$specialization', '$email', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Doctor added successfully!'); window.location.href='users.php';</script>";
} else {
    echo "<script>alert('An error occurred while adding the doctor.'); window.history.back();</script>";
}

$conn->close();
?>
