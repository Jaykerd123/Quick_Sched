<?php
session_start();

// Make sure user is logged in
if (!isset($_SESSION['id'])) {
    echo "Access denied. Please log in.";
    exit();
}

// DB connection
$conn = new mysqli("localhost", "root", "", "system_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user id from session
$user_id = $_SESSION['id'];

// Fetch appointments for the logged-in user
$sql = "SELECT * FROM appointments WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html>
<head>
    <title>My Appointments</title>
    <style>
        table {
            width: 90%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        th, td {
            padding: 12px;
            border: 1px solid #aaa;
            text-align: left;
        }
    </style>
</head>
<body>
    <h2 style="text-align:center;">My Appointments</h2>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Time</th>
                <th>Doctor</th>
                <th>Reason</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['preferred_date']) ?></td>
                <td><?= htmlspecialchars($row['preferred_time']) ?></td>
                <td><?= htmlspecialchars($row['preferred_doctor']) ?></td>
                <td><?= htmlspecialchars($row['reason']) ?></td>
                <td>Confirmed</td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">No appointments found.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
