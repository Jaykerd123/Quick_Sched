<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['code'])) {
    $user_code = trim($_POST['code']);

    if (!isset($_SESSION['reset_code']) || !isset($_SESSION['email'])) {
        echo "<script>alert('No reset code found. Please start the process again.'); window.location.href='fp-code.php';</script>";
        exit;
    }

    if ($user_code === (string)$_SESSION['reset_code']) {
        unset($_SESSION['reset_code']);

        // Redirect to next page
        echo "<script>window.location.href = 'next-action.php';</script>";
        exit;
    } else {
        echo "<script>alert('Invalid verification code. Please try again.'); window.location.href='z.php';</script>";
    }
} else {
    echo "<script>alert('Please enter the verification code.'); window.location.href='z.php';</script>";
}
